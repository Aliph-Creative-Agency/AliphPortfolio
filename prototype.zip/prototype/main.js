/* ALIPH prototype v03 — i18n, accordion library, motion (all pages) */

const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
gsap.registerPlugin(ScrollTrigger);

/* ══════════ i18n ══════════ */
const I18N = {
  navHome:   { ar: "الرئيسيّة", en: "Home" },
  navWork:   { ar: "الأعمال", en: "Work" },
  navAbout:  { ar: "من نحن", en: "About" },
  metaPlace: { ar: "القدس، جبل الزيتون", en: "Jerusalem, Mount of Olives" },
  metaIssue: { ar: "العدد ٠١ — حزيران ٢٠٢٦", en: "Issue 01 — June 2026" },
  hero1:     { ar: "استوديو", en: "A Creative" },
  hero2:     { ar: "إبداعي!", en: "Studio!" },
  /* the boxed letter completes the first word: أ + لِف / A + liph */
  heroPara:  {
    ar: "لِف استوديو يبدأ من حيث تبدأ الأشياء: من الحرف الأوّل. لكل علامةٍ نقطة أصلٍ تُبنى منها وتعود إليها، وعملنا هو العثور على تلك النقطة، ثم رسم النظام كاملًا منها — الاسم، والهويّة، والصوت، والطريقة التي تظهر بها العلامة في العالم.",
    en: "liph is a studio that begins where things begin: at the first letter. Every brand has an origin point it is built from and returns to. Our work is finding that point, then drawing the whole system from it — the name, the identity, the voice, and the way the brand shows up in the world.",
  },
  heroCap:   { ar: "من الاستوديو — القدس", en: "From the studio — Jerusalem" },
  heroFig:   { ar: "FIG. ٠١", en: "FIG. 01" },
  mq1: { ar: "هويّات بصريّة", en: "Visual Identities" },
  mq2: { ar: "صناعة محتوى", en: "Content Creation" },
  mq3: { ar: "تسويق مبتكر", en: "Creative Marketing" },
  mq4: { ar: "تنظيم فعاليّات", en: "Event Production" },
  svcBanner: { ar: "ماذا نفعل؟", en: "What we do?" },
  svc1: { ar: "هويّات بصريّة", en: "Identities" },
  svc2: { ar: "صناعة محتوى", en: "Content" },
  svc3: { ar: "تسويق مبتكر", en: "Marketing" },
  svc4: { ar: "تنظيم فعاليّات", en: "Events" },
  svc1Label: { ar: "IDENTITY", en: "هويّات بصريّة" },
  svc2Label: { ar: "CONTENT", en: "صناعة محتوى" },
  svc3Label: { ar: "MARKETING", en: "تسويق مبتكر" },
  svc4Label: { ar: "EVENTS", en: "تنظيم فعاليّات" },
  svcCta: { ar: "كل الأعمال في الأرشيف", en: "All work in the archive" },
  foot1: { ar: "لنبدأ من", en: "Let's start from" },
  foot2: { ar: "الألِف.", en: "the Aliph." },
  legal: { ar: "ألِف © ٢٠٢٦ — جميع الحقوق محفوظة", en: "Aliph © 2026 — All rights reserved" },
  libTitle: { ar: "الأرشيف", en: "Archive" },
  libStats: { ar: "٣ سنوات / ١٩ مشروعًا", en: "3 years / 19 projects" },
  libIndex: { ar: "فهرس", en: "Index" },
  libGallery: { ar: "معرض", en: "Gallery" },
  aboutBanner: { ar: "من نحن؟", en: "Who are we?" },
  teamBanner: { ar: "الفريق", en: "The Team" },
  cap1: { ar: "من جلسة تصوير — البلدة القديمة", en: "From a shoot — the Old City" },
  cap2: { ar: "وراء الكواليس — تجهيز فعاليّة", en: "Behind the scenes — event setup" },
  cap3: { ar: "نقاش تصميم — الاستوديو", en: "Design discussion — the studio" },
  quote: {
    ar: "«النتيجة يجب أن تبدو حتميّة: راسخة، مدروسة، وذات شخصيّة لا تُخطئها العين.»",
    en: "“The result should feel inevitable: rooted, considered, with a personality the eye can't miss.”",
  },
  quoteCite: { ar: "— دفتر ألِف", en: "— The Aliph notebook" },
  aboutH: { ar: "صوت واحد، حرفان، ولغتان.", en: "One sound, two letters, two languages." },
  aboutP: {
    ar: "نحن فريق صغير من القدس يصنع الهويّات والمحتوى من حرفها الأوّل. نبدأ من النقطة التي تُبنى منها الأشياء، ونرسم منها نظامًا كاملًا: الاسم، والهويّة، والصوت، والطريقة التي تظهر بها العلامة في العالم.",
    en: "We are a small team from Jerusalem crafting identities and content from their first letter. We start at the point things are built from, and draw a complete system out of it: the name, the identity, the voice, and the way the brand shows up in the world.",
  },
  m1Name: { ar: "عبد الله", en: "Abdallah" },
  m1Role: { ar: "مؤسّس — إدارة إبداعيّة", en: "Founder — Creative Direction" },
  m2Name: { ar: "جنى", en: "Jana" },
  m2Role: { ar: "تصميم — هويّات بصريّة", en: "Design — Visual Identities" },
  m3Name: { ar: "قريبًا", en: "Coming soon" },
  m3Role: { ar: "تصوير — توثيق", en: "Photography — Documentation" },
};

const CATS = [
  { id: "all",       ar: "الكل", en: "All" },
  { id: "identity",  ar: "هويّات بصريّة", en: "Identities" },
  { id: "content",   ar: "صناعة محتوى", en: "Content" },
  { id: "marketing", ar: "تسويق مبتكر", en: "Marketing" },
  { id: "events",    ar: "تنظيم فعاليّات", en: "Events" },
];

const PROJECTS = [
  { ar: "مؤسّسة بنيان",   en: "Bunyan Foundation",    year: 2026, count: 32, cat: "identity",  seed: "aliph01" },
  { ar: "مواسم الزيتون",  en: "Olive Seasons",        year: 2026, count: 47, cat: "content",   seed: "aliph02" },
  { ar: "ورشة الخط",      en: "Calligraphy Workshop", year: 2026, count: 15, cat: "events",    seed: "aliph03" },
  { ar: "حارة النصارى",   en: "Christian Quarter",    year: 2026, count: 22, cat: "content",   seed: "aliph04" },
  { ar: "مقهى الجبل",     en: "Mountain Café",        year: 2026, count: 18, cat: "identity",  seed: "aliph05" },
  { ar: "معرض التراث",    en: "Heritage Fair",        year: 2026, count: 26, cat: "events",    seed: "aliph06" },
  { ar: "سوق البلدة",     en: "Old Town Market",      year: 2026, count: 21, cat: "marketing", seed: "aliph07" },
  { ar: "جبل الزيتون",    en: "Mount of Olives",      year: 2026, count: 12, cat: "content",   seed: "aliph08" },
  { ar: "ليالي رمضان",    en: "Ramadan Nights",       year: 2025, count: 64, cat: "events",    seed: "aliph09" },
  { ar: "البلدة القديمة", en: "The Old City",         year: 2025, count: 33, cat: "content",   seed: "aliph10" },
  { ar: "مهرجان الصيف",   en: "Summer Festival",      year: 2025, count: 41, cat: "events",    seed: "aliph11" },
  { ar: "دار الأيتام",    en: "Orphanage Campaign",   year: 2025, count: 17, cat: "marketing", seed: "aliph12" },
  { ar: "مطعم الديوان",   en: "Al-Diwan Restaurant",  year: 2025, count: 25, cat: "identity",  seed: "aliph13" },
  { ar: "أسبوع التصميم",  en: "Design Week",          year: 2025, count: 19, cat: "events",    seed: "aliph14" },
  { ar: "افتتاح المكتبة", en: "Library Opening",      year: 2024, count: 29, cat: "events",    seed: "aliph15" },
  { ar: "حملة التخرّج",   en: "Graduation Campaign",  year: 2024, count: 36, cat: "marketing", seed: "aliph16" },
  { ar: "بيت الشباب",     en: "Youth House",          year: 2024, count: 14, cat: "identity",  seed: "aliph17" },
  { ar: "نادي القراءة",   en: "Reading Club",         year: 2024, count: 11, cat: "content",   seed: "aliph18" },
  { ar: "عرس فلسطيني",    en: "Palestinian Wedding",  year: 2024, count: 53, cat: "content",   seed: "aliph19" },
];

let lang = localStorage.getItem("aliph-lang") === "en" ? "en" : "ar";

const AR_DIGITS = ["٠","١","٢","٣","٤","٥","٦","٧","٨","٩"];
function num(n) {
  const s = String(n);
  return lang === "ar" ? s.replace(/[0-9]/g, (d) => AR_DIGITS[+d]) : s;
}

function applyI18n() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const entry = I18N[el.dataset.i18n];
    if (entry) el.textContent = entry[lang];
  });
  document.querySelectorAll(".sc-num[data-num]").forEach((el) => {
    el.textContent = num(el.dataset.num);
  });
  document.querySelectorAll(".js-lang").forEach((b) => (b.textContent = lang === "ar" ? "EN" : "عربي"));
  renderExample(currentService);
  renderLibrary();
}

document.addEventListener("click", (e) => {
  const b = e.target.closest(".js-lang");
  if (!b) return;
  lang = lang === "ar" ? "en" : "ar";
  localStorage.setItem("aliph-lang", lang);
  applyI18n();
});

/* ══════════ page transition curtain ══════════ */
const curtain = document.getElementById("curtain");

if (curtain && !prefersReduced) {
  gsap.to(curtain, {
    yPercent: -100,
    duration: 0.8,
    delay: 0.15,
    ease: "power4.inOut",
    onComplete: () => (curtain.style.display = "none"),
  });
} else if (curtain) {
  curtain.style.display = "none";
}
window.addEventListener("pageshow", (e) => {
  if (e.persisted && curtain) curtain.style.display = "none";
});

document.addEventListener("click", (e) => {
  const a = e.target.closest("a[href$='.html']");
  if (!a || prefersReduced || !curtain) return;
  const href = a.getAttribute("href");
  if (!href || href.startsWith("http")) return;
  e.preventDefault();
  curtain.style.display = "flex";
  gsap.fromTo(curtain,
    { yPercent: 100 },
    { yPercent: 0, duration: 0.6, ease: "power4.inOut", onComplete: () => (window.location.href = href) }
  );
});

/* ══════════ nav overlay + burger morph ══════════ */
const menuBtn = document.getElementById("menuBtn");
const overlay = document.getElementById("navOverlay");

if (menuBtn && overlay) {
  const items = overlay.querySelectorAll(".nav-item");
  let open = false;
  menuBtn.addEventListener("click", () => {
    open = !open;
    document.body.classList.toggle("nav-open", open);
    menuBtn.setAttribute("aria-expanded", String(open));
    if (prefersReduced) return;
    if (open) {
      gsap.fromTo(overlay, { yPercent: -100 }, { yPercent: 0, duration: 0.65, ease: "power4.inOut" });
      gsap.fromTo(items,
        { yPercent: 60, opacity: 0 },
        { yPercent: 0, opacity: 1, duration: 0.6, stagger: 0.07, delay: 0.3, ease: "power3.out" }
      );
    } else {
      gsap.to(overlay, {
        yPercent: -100,
        duration: 0.55,
        ease: "power4.inOut",
        onComplete: () => gsap.set(overlay, { yPercent: 0 }),
      });
    }
  });
}

/* ══════════ index page ══════════ */
const page = document.body.dataset.page;

if (page === "index" && !prefersReduced) {
  gsap.from(".rule-double", { scaleX: 0, transformOrigin: "right center", duration: 1, ease: "power3.inOut" });
  gsap.from(".hero-title .line", { yPercent: 110, duration: 1, stagger: 0.12, delay: 0.4, ease: "power4.out" });
  gsap.from(".dropcap-block", { opacity: 0, y: 24, duration: 0.9, delay: 0.8, ease: "power2.out" });
  gsap.from(".hero-media", { opacity: 0, duration: 1, delay: 0.6, ease: "power2.out" });

  gsap.utils.toArray(".banner h2").forEach((el) => {
    gsap.from(el, {
      yPercent: 60, opacity: 0, duration: 0.9, ease: "power3.out",
      scrollTrigger: { trigger: el, start: "top 88%" },
    });
  });
  gsap.utils.toArray(".service-cell").forEach((el) => {
    gsap.from(el, {
      opacity: 0, y: 20, duration: 0.7, ease: "power2.out",
      scrollTrigger: { trigger: el, start: "top 94%" },
    });
  });
  gsap.from(".footer-title .line", {
    yPercent: 110, duration: 1, stagger: 0.1, ease: "power4.out",
    scrollTrigger: { trigger: ".footer", start: "top 75%" },
  });
}

/* marquee */
const track = document.getElementById("marqueeTrack");
if (track && !prefersReduced) {
  track.innerHTML += track.innerHTML + track.innerHTML;
  gsap.to(track, { xPercent: 33.333, ease: "none", duration: 26, repeat: -1 });
}

/* services tabs */
const EXAMPLES = {
  identity: {
    kicker: { ar: "مثال — هويّة بصريّة", en: "Example — visual identity" },
    title: { ar: "مؤسّسة بنيان بحلّتها الجديدة", en: "Bunyan Foundation, renewed" },
    desc: {
      ar: "حضورٌ أوضح وأكثر حداثة، مع الحفاظ على روح العلامة القريبة والمألوفة: شعار، ألوان، تغليف، وظهور يومي.",
      en: "A clearer, more modern presence that keeps the brand's familiar spirit: logo, colors, packaging, and daily touchpoints.",
    },
  },
  content: {
    kicker: { ar: "مثال — صناعة محتوى", en: "Example — content creation" },
    title: { ar: "مواسم الزيتون: توثيق بصري", en: "Olive Seasons: a visual record" },
    desc: {
      ar: "سلسلة محتوى مصوّر لمواسم القطف، من الحقل إلى المعصرة: ٤٧ لقطة، وقصص يوميّة، وهويّة لونيّة واحدة.",
      en: "A photographed content series across the harvest, from field to press: 47 shots, daily stories, one visual tone.",
    },
  },
  marketing: {
    kicker: { ar: "مثال — تسويق مبتكر", en: "Example — creative marketing" },
    title: { ar: "حملة سوق البلدة", en: "The Old Town Market campaign" },
    desc: {
      ar: "حملة إعلانيّة كاملة لإحياء السوق القديم: مفهوم، تصوير، وإدارة منصّات لثلاثة أشهر متواصلة.",
      en: "A full campaign to revive the old market: concept, photography, and three months of channel management.",
    },
  },
  events: {
    kicker: { ar: "مثال — تنظيم فعاليّات", en: "Example — event production" },
    title: { ar: "ليالي رمضان", en: "Ramadan Nights" },
    desc: {
      ar: "تنظيم وتوثيق فعاليّة مجتمعيّة على مدار الشهر: برنامج، هويّة بصريّة للفعاليّة، وتغطية يوميّة.",
      en: "A month-long community event, organized and documented: program, event identity, and daily coverage.",
    },
  },
};

let currentService = "identity";

function renderExample(id) {
  const data = EXAMPLES[id];
  const kicker = document.getElementById("exampleKicker");
  if (!data || !kicker) return;
  kicker.textContent = data.kicker[lang];
  document.getElementById("exampleTitle").textContent = data.title[lang];
  document.getElementById("exampleDesc").textContent = data.desc[lang];
}

document.querySelectorAll(".service-cell").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".service-cell").forEach((b) => {
      b.classList.remove("is-active");
      b.setAttribute("aria-selected", "false");
    });
    btn.classList.add("is-active");
    btn.setAttribute("aria-selected", "true");
    currentService = btn.dataset.service;
    if (prefersReduced) { renderExample(currentService); return; }
    gsap.to("#serviceExample", {
      opacity: 0, y: 10, duration: 0.22, ease: "power2.in",
      onComplete() {
        renderExample(currentService);
        gsap.to("#serviceExample", { opacity: 1, y: 0, duration: 0.35, ease: "power2.out" });
      },
    });
  });
});

/* ══════════ library: category accordion ══════════ */
const accRoot = document.getElementById("accRoot");
let openCat = "all";

function renderLibrary() {
  if (!accRoot) return;
  accRoot.innerHTML = "";
  CATS.forEach((cat) => {
    const items = cat.id === "all" ? PROJECTS : PROJECTS.filter((p) => p.cat === cat.id);
    const years = [...new Set(items.map((p) => p.year))].sort((a, b) => b - a);

    const panel = document.createElement("section");
    panel.className = "acc-panel" + (cat.id === openCat ? " open" : "");
    panel.dataset.cat = cat.id;

    const yearsHtml = years.map((y) => {
      const yi = items.filter((p) => p.year === y);
      const tiles = yi.map((p) => `
        <figure class="tile">
          <div class="tile-img"><img src="https://picsum.photos/seed/${p.seed}/600/400" alt="${p[lang]}" loading="lazy"></div>
          <figcaption><span>${p[lang]}</span><span class="t-count">${num(p.count)}</span></figcaption>
        </figure>`).join("");
      const rows = yi.map((p) => `
        <div class="lib-list-row"><span>${p[lang]}</span><span class="t-count">${num(p.count)}</span></div>`).join("");
      return `
        <div class="lib-year">
          <div class="lib-year-head" aria-hidden="true">
            <span class="year-num">${num(y)}</span>
            <span class="year-count">${num(yi.length)}</span>
          </div>
          <div class="lib-grid">${tiles}</div>
          <div class="lib-list">${rows}</div>
        </div>`;
    }).join("");

    panel.innerHTML = `
      <button class="spine" aria-expanded="${cat.id === openCat}">
        <span class="spine-name">${cat[lang]}</span>
        <span class="spine-count">${num(items.length)}</span>
      </button>
      <div class="panel-body">
        <div class="panel-head">
          <h2>${cat[lang]}</h2>
          <span class="panel-count">${num(items.length)}</span>
        </div>
        ${yearsHtml}
      </div>`;

    panel.querySelector(".spine").addEventListener("click", () => {
      if (openCat === cat.id) return;
      openCat = cat.id;
      accRoot.querySelectorAll(".acc-panel").forEach((p) => {
        const isOpen = p.dataset.cat === openCat;
        p.classList.toggle("open", isOpen);
        p.querySelector(".spine").setAttribute("aria-expanded", String(isOpen));
        if (isOpen) p.querySelector(".panel-body").scrollTop = 0;
      });
    });

    accRoot.appendChild(panel);
  });
}

/* library view toggle (gallery / index) */
const viewIndex = document.getElementById("viewIndex");
const viewPhoto = document.getElementById("viewPhoto");
if (viewIndex && viewPhoto) {
  viewIndex.addEventListener("click", () => {
    document.body.classList.add("lib-index");
    viewIndex.classList.add("on");
    viewPhoto.classList.remove("on");
  });
  viewPhoto.addEventListener("click", () => {
    document.body.classList.remove("lib-index");
    viewPhoto.classList.add("on");
    viewIndex.classList.remove("on");
  });
}

/* ══════════ about page reveals ══════════ */
if (page === "about" && !prefersReduced) {
  gsap.utils.toArray(".banner h2").forEach((el) => {
    gsap.from(el, {
      yPercent: 60, opacity: 0, duration: 0.9, ease: "power3.out",
      scrollTrigger: { trigger: el, start: "top 88%" },
    });
  });
  gsap.utils.toArray(".clip, .member").forEach((el) => {
    gsap.from(el, {
      opacity: 0, y: 26, duration: 0.7, ease: "power2.out",
      scrollTrigger: { trigger: el, start: "top 92%" },
    });
  });
  gsap.from(".footer-title .line", {
    yPercent: 110, duration: 1, stagger: 0.1, ease: "power4.out",
    scrollTrigger: { trigger: ".footer", start: "top 75%" },
  });
}

/* ══════════ boot ══════════ */
applyI18n();
